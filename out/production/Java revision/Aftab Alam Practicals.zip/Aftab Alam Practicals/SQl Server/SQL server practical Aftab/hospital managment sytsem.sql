--Hospital managment system ;
CREATE TABLE Patients (
    PatientID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    DOB DATE,
    Gender NVARCHAR(10),
    Address NVARCHAR(100),
    PhoneNumber NVARCHAR(15),
    Email NVARCHAR(50)
);

INSERT INTO Patients (FirstName, LastName, DOB, Gender, Address, PhoneNumber, Email)
VALUES
('Ali', 'Khan', '1985-07-15', 'Male', 'Karachi, Sindh', '03123456789', 'ali.khan@email.com'),
('Sara', 'Javed', '1992-03-10', 'Female', 'Lahore, Punjab', '03234567890', 'sara.javed@email.com'),
('Mohammad', 'Irfan', '1980-06-25', 'Male', 'Islamabad, ICT', '03345678901', 'mohammad.irfan@email.com'),
('Ayesha', 'Siddiqui', '1995-10-12', 'Female', 'Rawalpindi, Punjab', '03456789012', 'ayesha.siddiqui@email.com'),
('Ahmed', 'Shah', '1988-11-07', 'Male', 'Faisalabad, Punjab', '03567890123', 'ahmed.shah@email.com'),
('Nida', 'Bashir', '1993-01-22', 'Female', 'Karachi, Sindh', '03349876123', 'nida.bashir@email.com');

CREATE TABLE Doctors (
    DoctorID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    Specialization NVARCHAR(50),
    ContactNumber NVARCHAR(15),
    Email NVARCHAR(50)
);

INSERT INTO Doctors (FirstName, LastName, Specialization, ContactNumber, Email)
VALUES
('Dr. Ali', 'Raza', 'Cardiologist', '03331234567', 'ali.raza@hospital.com'),
('Dr. Sara', 'Khan', 'Neurologist', '03342345678', 'sara.khan@hospital.com'),
('Dr. Farhan', 'Iqbal', 'Orthopedic', '03453456789', 'farhan.iqbal@hospital.com'),
('Dr. Ayesha', 'Shaikh', 'Dermatologist', '03564567890', 'ayesha.shaikh@hospital.com'),
('Dr. Imran', 'Nadeem', 'Pediatrician', '03675678901', 'imran.nadeem@hospital.com'),
('Dr. Mehmood', 'Javed', 'General Physician', '03786789012', 'mehmood.javed@hospital.com');

CREATE TABLE Appointments (
    AppointmentID INT PRIMARY KEY IDENTITY(1,1),
    PatientID INT FOREIGN KEY REFERENCES Patients(PatientID),
    DoctorID INT FOREIGN KEY REFERENCES Doctors(DoctorID),
    AppointmentDate DATETIME,
    ReasonForVisit NVARCHAR(100)
);

INSERT INTO Appointments (PatientID, DoctorID, AppointmentDate, ReasonForVisit)
VALUES
(1, 1, '2024-11-20 10:00:00', 'Heart checkup'),
(2, 2, '2024-11-21 14:00:00', 'Migraine treatment'),
(3, 3, '2024-11-22 09:30:00', 'Knee pain'),
(4, 4, '2024-11-23 11:15:00', 'Skin rash'),
(5, 5, '2024-11-24 16:00:00', 'Child vaccination'),
(6, 6, '2024-12-01 13:00:00', 'Routine checkup');

CREATE TABLE Medicines (
    MedicineID INT PRIMARY KEY IDENTITY(1,1),
    MedicineName NVARCHAR(100),
    Category NVARCHAR(50),
    Price DECIMAL(10, 2),
    StockQuantity INT
);

INSERT INTO Medicines (MedicineName, Category, Price, StockQuantity)
VALUES
('Paracetamol', 'Pain Reliever', 100.50, 100),
('Aspirin', 'Pain Reliever', 150.00, 75),
('Amoxicillin', 'Antibiotic', 200.00, 60),
('Metformin', 'Diabetic', 250.00, 50),
('Ibuprofen', 'Anti-Inflammatory', 120.00, 120),
('Cetirizine', 'Antihistamine', 80.00, 95);
CREATE TABLE Billings (
    BillID INT PRIMARY KEY IDENTITY(1,1),
    PatientID INT FOREIGN KEY REFERENCES Patients(PatientID),
    Amount DECIMAL(10, 2),
    DateIssued DATETIME,
    Status NVARCHAR(20)
);

INSERT INTO Billings (PatientID, Amount, DateIssued, Status)
VALUES
(1, 5000.00, '2024-11-20 11:00:00', 'Paid'),
(2, 3500.00, '2024-11-21 15:00:00', 'Unpaid'),
(3, 4500.00, '2024-11-22 10:30:00', 'Paid'),
(4, 6000.00, '2024-11-23 12:00:00', 'Unpaid'),
(5, 3000.00, '2024-11-24 17:00:00', 'Paid'),
(6, 7000.00, '2024-12-01 14:00:00', 'Unpaid');
	
	CREATE VIEW vw_hospital_view AS
SELECT 
    p.PatientID,
    p.FirstName AS PatientFirstName,
    p.LastName AS PatientLastName,
    p.DOB AS PatientDOB,
    p.Gender AS PatientGender,
    p.Address AS PatientAddress,
    p.PhoneNumber AS PatientPhoneNumber,
    p.Email AS PatientEmail,
    
    d.FirstName AS DoctorFirstName,
    d.LastName AS DoctorLastName,
    d.Specialization AS DoctorSpecialization,

    a.AppointmentID,
    a.AppointmentDate,
    a.ReasonForVisit,
    
    b.BillID,
    b.Amount AS BillAmount,
    b.DateIssued AS BillDateIssued,
    b.Status AS BillStatus,
    
    m.MedicineName,
    m.Category AS MedicineCategory,
    m.Price AS MedicinePrice,
    m.StockQuantity AS MedicineStock
FROM 
    Patients p
JOIN 
    Appointments a ON p.PatientID = a.PatientID
JOIN 
    Doctors d ON a.DoctorID = d.DoctorID
LEFT JOIN 
    Billings b ON p.PatientID = b.PatientID
CROSS JOIN 
    (SELECT TOP 1 * FROM Medicines ORDER BY NEWID()) m 

