CREATE TABLE Products (
    ProductID INT PRIMARY KEY IDENTITY(1,1),
    ProductName NVARCHAR(100),
    Category NVARCHAR(50),
    Price DECIMAL(10, 2),
    Quantity INT
);

INSERT INTO Products (ProductName, Category, Price, Quantity)
VALUES
('Paracetamol', 'Medicine', 50.00, 200),
('Ibuprofen', 'Medicine', 120.00, 150),
('Syringe', 'Equipment', 15.00, 300),
('Bandage', 'Equipment', 30.00, 100),
('Aspirin', 'Medicine', 80.00, 120),
('Oxygen Mask', 'Equipment', 250.00, 50);

CREATE TABLE Suppliers (
    SupplierID INT PRIMARY KEY IDENTITY(1,1),
    SupplierName NVARCHAR(100),
    ContactPerson NVARCHAR(50),
    PhoneNumber NVARCHAR(15),
    Email NVARCHAR(50)
);

INSERT INTO Suppliers (SupplierName, ContactPerson, PhoneNumber, Email)
VALUES
('MedSupply Co.', 'John Doe', '03334567890', 'john@medsupply.com'),
('HealthFirst Ltd.', 'Sara Ali', '03212345678', 'sara@healthfirst.com'),
('PharmaWorld', 'Usman Khan', '03123456789', 'usman@pharmaworld.com'),
('MedStore', 'Ali Ahmed', '03098765432', 'ali@medstore.com'),
('Pharmabest', 'Fatima Zaman', '03122334455', 'fatima@pharmabest.com'),
('GlobalMedic', 'Hassan Iqbal', '03211223344', 'hassan@globalmedic.com');

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY IDENTITY(1,1),
    SupplierID INT FOREIGN KEY REFERENCES Suppliers(SupplierID),
    OrderDate DATETIME,
    TotalAmount DECIMAL(10, 2)
);

INSERT INTO Orders (SupplierID, OrderDate, TotalAmount)
VALUES
(1, '2024-11-01', 5000.00),
(2, '2024-11-03', 8000.00),
(3, '2024-11-05', 3000.00),
(4, '2024-11-07', 4500.00),
(5, '2024-11-09', 5500.00),
(6, '2024-11-30', 6000.00);

CREATE TABLE OrderDetails (
    OrderDetailID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT FOREIGN KEY REFERENCES Orders(OrderID),
    ProductID INT FOREIGN KEY REFERENCES Products(ProductID),
    Quantity INT,
    Price DECIMAL(10, 2)
);

INSERT INTO OrderDetails (OrderID, ProductID, Quantity, Price)
VALUES
(1, 1, 50, 50.00),
(1, 2, 30, 120.00),
(2, 3, 100, 15.00),
(2, 4, 50, 30.00),
(3, 5, 40, 80.00),
(6, 6, 20, 250.00);

CREATE TABLE InventoryTransactions (
    TransactionID INT PRIMARY KEY IDENTITY(1,1),
    ProductID INT FOREIGN KEY REFERENCES Products(ProductID),
    TransactionDate DATETIME,
    TransactionType NVARCHAR(50), -- 'Received', 'Consumed'
    Quantity INT
);

INSERT INTO InventoryTransactions (ProductID, TransactionDate, TransactionType, Quantity)
VALUES
(1, '2024-11-02', 'Received', 50),
(2, '2024-11-04', 'Received', 30),
(3, '2024-11-06', 'Consumed', 20),
(4, '2024-11-08', 'Received', 100),
(5, '2024-11-10', 'Consumed', 40),
(6, '2024-11-25', 'Received', 20);

CREATE VIEW vw_inventory_report AS
SELECT 
    p.ProductID,
    p.ProductName,
    p.Category,
    p.Price AS ProductPrice,
    p.Quantity AS AvailableQuantity,
    
    s.SupplierName,
    s.ContactPerson AS SupplierContactPerson,
    s.PhoneNumber AS SupplierPhone,
    s.Email AS SupplierEmail,
    o.OrderDate,
    o.TotalAmount AS OrderTotalAmount,

    od.Quantity AS OrderQuantity,
    od.Price AS OrderPrice,

    it.TransactionDate AS InventoryTransactionDate,
    it.TransactionType AS InventoryTransactionType,
    it.Quantity AS InventoryQuantity

FROM 
    Products p
JOIN 
    OrderDetails od ON p.ProductID = od.ProductID
JOIN 
    Orders o ON od.OrderID = o.OrderID
JOIN 
    Suppliers s ON o.SupplierID = s.SupplierID
LEFT JOIN 
    InventoryTransactions it ON p.ProductID = it.ProductID
;


SELECT * FROM vw_inventory_report;
