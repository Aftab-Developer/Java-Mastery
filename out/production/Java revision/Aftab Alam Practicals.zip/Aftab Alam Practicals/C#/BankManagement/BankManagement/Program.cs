﻿using System;

namespace BankAccountManagementSystem
{
    public class BankAccount
    {
        public int AccountNumber { get; set; }
        public string AccountHolderName { get; set; }
        public double Balance { get; set; }

        public BankAccount(int accountNumber, string accountHolderName, double initialBalance)
        {
            AccountNumber = accountNumber;
            AccountHolderName = accountHolderName;
            Balance = initialBalance;
        }

        public void Deposit(double amount)
        {
            if (amount > 0)
            {
                Balance += amount;
                Console.WriteLine($"Deposited: {amount:C}. New balance: {Balance:C}");
            }
            else
            {
                Console.WriteLine("Deposit amount must be greater than 0.");
            }
        }

        public void Withdraw(double amount)
        {
            if (amount <= 0)
            {
                Console.WriteLine("Withdrawal amount must be greater than 0.");
                return;
            }

            if (amount > Balance)
            {
                Console.WriteLine("Insufficient balance for withdrawal.");
            }
            else
            {
                Balance -= amount;
                Console.WriteLine($"Withdrew: {amount:C}. New balance: {Balance:C}");
            }
        }

        public void CheckBalance()
        {
            Console.WriteLine($"Current balance: {Balance:C}");
        }
    }

    class Program
    {
        static void Main()
        {
            BankAccount account = null;
            bool running = true;

            while (running)
            {
                Console.Clear();
                Console.WriteLine("Bank Account Management System");
                Console.WriteLine("1. Create New Account");
                Console.WriteLine("2. Deposit Money");
                Console.WriteLine("3. Withdraw Money");
                Console.WriteLine("4. Check Balance");
                Console.WriteLine("5. Exit");
                Console.Write("Enter your choice: ");

                int choice;
                bool validChoice = int.TryParse(Console.ReadLine(), out choice);

                if (!validChoice || choice < 1 || choice > 5)
                {
                    Console.WriteLine("Invalid choice, please try again.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        if (account != null)
                        {
                            Console.WriteLine("Account already created. Please exit and restart to create a new one.");
                            break;
                        }

                        Console.WriteLine("Enter Account Number:");
                        int accountNumber = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Account Holder Name:");
                        string accountHolderName = Console.ReadLine();
                        Console.WriteLine("Enter Initial Deposit:");
                        double initialDeposit = double.Parse(Console.ReadLine());

                        account = new BankAccount(accountNumber, accountHolderName, initialDeposit);
                        Console.WriteLine("Account created successfully!");
                        break;

                    case 2:
                        if (account == null)
                        {
                            Console.WriteLine("No account found. Please create an account first.");
                            break;
                        }

                        Console.WriteLine("Enter deposit amount:");
                        double depositAmount = double.Parse(Console.ReadLine());
                        account.Deposit(depositAmount);
                        break;

                    case 3:
                        if (account == null)
                        {
                            Console.WriteLine("No account found. Please create an account first.");
                            break;
                        }

                        Console.WriteLine("Enter withdrawal amount:");
                        double withdrawAmount = double.Parse(Console.ReadLine());
                        account.Withdraw(withdrawAmount);
                        break;

                    case 4:
                        if (account == null)
                        {
                            Console.WriteLine("No account found. Please create an account first.");
                            break;
                        }

                        account.CheckBalance();
                        break;

                    case 5:
                        running = false;
                        break;
                }

                if (running)
                {
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
            }
        }
    }
}
