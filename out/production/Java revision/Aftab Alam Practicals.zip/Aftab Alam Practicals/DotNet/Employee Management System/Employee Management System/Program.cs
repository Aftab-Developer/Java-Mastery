﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EmployeeManagementSystem
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public double Salary { get; set; }

        public Employee(int id, string name, string department, double salary)
        {
            EmployeeID = id;
            Name = name;
            Department = department;
            Salary = salary;
        }
    }

    class Program
    {
        public delegate double BonusCalculator(double salary, double bonusPercentage);

        static void Main()
        {
            List<Employee> employees = new List<Employee>();
            Dictionary<string, double> departmentBonuses = new Dictionary<string, double>
            {
                { "HR", 10.0 },
                { "Engineering", 15.0 },
                { "Sales", 5.0 }
            };

            BonusCalculator bonusDelegate = new BonusCalculator(CalculateBonus);

            bool running = true;
            while (running)
            {
                Console.Clear();
                Console.WriteLine("Employee Management System");
                Console.WriteLine("1. Add Employee");
                Console.WriteLine("2. View All Employees");
                Console.WriteLine("3. Search Employees by Department");
                Console.WriteLine("4. Calculate Bonus");
                Console.WriteLine("5. Exit");
                Console.Write("Enter your choice: ");
                int choice;
                bool validChoice = int.TryParse(Console.ReadLine(), out choice);

                if (!validChoice || choice < 1 || choice > 5)
                {
                    Console.WriteLine("Invalid choice, please try again.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                       
                        Console.WriteLine("Enter Employee ID:");
                        int id = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Name:");
                        string name = Console.ReadLine();
                        Console.WriteLine("Enter Department:");
                        string department = Console.ReadLine();
                        Console.WriteLine("Enter Salary:");
                        double salary = double.Parse(Console.ReadLine());

                        employees.Add(new Employee(id, name, department, salary));
                        Console.WriteLine("Employee added successfully!");
                        break;

                    case 2:
                      
                        if (employees.Count == 0)
                        {
                            Console.WriteLine("No employees found.");
                        }
                        else
                        {
                            foreach (var emp in employees)
                            {
                                Console.WriteLine($"ID: {emp.EmployeeID}, Name: {emp.Name}, Department: {emp.Department}, Salary: {emp.Salary:C}");
                            }
                        }
                        break;

                    case 3:
                      
                        Console.WriteLine("Enter Department to search:");
                        string searchDept = Console.ReadLine();
                        var filteredEmployees = employees.Where(e => e.Department.Equals(searchDept, StringComparison.OrdinalIgnoreCase)).ToList();
                        if (filteredEmployees.Count == 0)
                        {
                            Console.WriteLine("No employees found in this department.");
                        }
                        else
                        {
                            foreach (var emp in filteredEmployees)
                            {
                                Console.WriteLine($"ID: {emp.EmployeeID}, Name: {emp.Name}, Salary: {emp.Salary:C}");
                            }
                        }
                        break;

                    case 4:
                        
                        Console.WriteLine("Enter Employee ID to calculate bonus:");
                        int empId = int.Parse(Console.ReadLine());
                        var employeeToBonus = employees.FirstOrDefault(e => e.EmployeeID == empId);
                        if (employeeToBonus != null)
                        {
                            double bonusPercentage = departmentBonuses.ContainsKey(employeeToBonus.Department) ? departmentBonuses[employeeToBonus.Department] : 0.0;
                            double bonus = bonusDelegate(employeeToBonus.Salary, bonusPercentage);
                            Console.WriteLine($"Employee ID: {empId}, Bonus: {bonus:C}");
                        }
                        else
                        {
                            Console.WriteLine("Employee not found.");
                        }
                        break;

                    case 5:
                        running = false;
                        break;

                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }

                if (running)
                {
                    Console.WriteLine("Press any key to return to the menu...");
                    Console.ReadKey();
                }
            }
        }

        public static double CalculateBonus(double salary, double bonusPercentage)
        {
            return salary * (bonusPercentage / 100);
        }
    }
}
